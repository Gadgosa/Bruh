#Створи власний Шутер!

from pygame import *
